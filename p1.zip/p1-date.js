/*
    CIT 281 Project 1
    Name: Aidan Range
*/

// Output the day of the week of the current day
console.log(['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][new Date().getDay()]);
